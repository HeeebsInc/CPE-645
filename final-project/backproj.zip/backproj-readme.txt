save both 
backproj.m
backproj_demo.m
in the same directory.

In Matlab, use "cd" to chand to this directory, the type
backproj_demo

You need to hit "enter" to keep it going.